"use strict";
var PROTO_PATH = __dirname + '/grpc.proto';
var grpc = require('@grpc/grpc-js');
var protoLoader = require('@grpc/proto-loader');
var packageDefinition = protoLoader.loadSync(
    PROTO_PATH,
    {
      keepCase: true,
      longs: String,
      enums: String,
      defaults: true,
      oneofs: true
    });
var grpc_proto = grpc.loadPackageDefinition(packageDefinition).grpcserv;

//client oluşturma
var client = new grpc_proto.grpcServ('localhost:5000', grpc.credentials.createInsecure());  


//redis call fonksiyonu
let keyParam = "user2"
//call fonksiyonunun key parametresi keyParam olarak tanımlandı
client.Get({ key: keyParam }, function (err, response) {      
  console.log("REDIS KEY: ", keyParam, "VALUE: ", response.resp);
});


